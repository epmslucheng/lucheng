#!/bin/sh
DEPLOY_PATH='/usr/local/deploy'
export DEPLOY_PATH
#指定日志文件
LOGFILE="$DEPLOY_PATH/log/$1"
export LOGFILE
USER="$2"
SLEEP_SECONDS=3s

  #定义是否安装标识
MODULESFLAG="0"
ZKFLAG="0"
REDISFLAG="0"
NGINXFLAG="0"
KAFKAFLAG="0"
MONITORSERVERFLAG="0"

readSingleDeployConfig(){

        MODULESFLAG="1"
        ZKFLAG="1"
        REDISFLAG="1"
        NGINXFLAG="1"
        MONITORSERVERFLAG="1"
        KAFKAFLAG="1"
        #zk集群配置
        echo "config zookeeper..." >> $LOGFILE
        cd $DEPLOY_PATH/config/zk
        cp zoo-group-default.cfg zoo.cfg

        #zk连接字符串
        cp zkConfig-default.properties zkConfig.properties
        ZKADDRESSES="$NODEIP:27101"
        sed -i "s/ZKADDRESSES/$ZKADDRESSES/g" zkConfig.properties
        #设置dubbo.properties
        cd $DEPLOY_PATH/config/module
        cp dubbo-default.properties dubbo.properties
        sed -i "s/DUBBO_REGISTRY_ADDRESS/$ZKADDRESSES/g" dubbo.properties

        #redis配置
        echo "config redis..." >> $LOGFILE
        cd $DEPLOY_PATH/config/redis
        cp redis-default.conf redis.conf
        sed -i "s/NODEIP/$NODEIP/g" redis.conf
        
        cp sentinel-default.conf sentinel.conf
        sed -i "s/SENTINELIP/$NODEIP/g;s/MASTERIP/$NODEIP/g" sentinel.conf

        REDISADDRESS=${NODEIP}":27202"
        #redis连接字符串
        cp redisConfig-default.properties redisConfig.properties
        sed -i "s/REDISIP/$REDISADDRESS/g" redisConfig.properties

        #nginx配置
        echo "config nginx..." >> $LOGFILE
        cd $DEPLOY_PATH/config/nginx
        cp nginx-group-default.conf nginx.conf
        sed -i "/#PORTAL_SERVER_LIST_END/i\server $NODEIP:28102;" nginx.conf
        sed -i "/#INTERFACE_SERVER_LIST_END/i\server $NODEIP:28602;" nginx.conf
        sed -i "/#AUTHZ_SERVER_LIST_END/i\server $NODEIP:28702;" nginx.conf
        sed -i "/#MONITOR_SERVER_LIST_END/i\server $NODEIP:29102;" nginx.conf

        #kafaka配置
        echo "config kafka..." >> $LOGFILE
        cd $DEPLOY_PATH/config/kafka
        cp kafka.server.default.properties server.properties
        KAFKA_ZK=$NODEIP:27101
        sed -i "s#KAFKA_UNIQUE_ID#0#g;s#NODE_IP#$NODEIP#g;s#KAFKA_LOG_DIRS#/usr/local/karaf/kafka_2.11-1.0.0/logs#g;s#KAFKA_ZK#$KAFKA_ZK#g" server.properties
        KAFKA_SERVER_HOST=$NODEIP:27301
        cp kafkaConfig.default.properties kafkaConfig.properties
        sed -i "s#KAFKA_SERVER_HOST#$KAFKA_SERVER_HOST#g" kafkaConfig.properties
}

readDualDeployConfig(){
    NODE1IP=`cat $DEPLOY_CONFIG | awk '/NODE1IP/' | awk -F '=' '{printf $2}'`
    NODE2IP=`cat $DEPLOY_CONFIG | awk '/NODE2IP/' | awk -F '=' '{printf $2}'`
    VIRTUALIP=`cat $DEPLOY_CONFIG | awk '/VIRTUALIP/' | awk -F '=' '{printf $2}'`
    DESIP=`cat $DEPLOY_CONFIG | awk '/DESIP/' | awk -F '=' '{printf $2}'`
    MONITORSERVERIP=`cat $DEPLOY_CONFIG | awk '/MONITORSERVERIP/' | awk -F '=' '{printf $2}'`
    NODE1NETCARD=`cat $DEPLOY_CONFIG | awk '/NODE1NETCARD/' | awk -F '=' '{printf $2}'`
    NODE2NETCARD=`cat $DEPLOY_CONFIG | awk '/NODE2NETCARD/' | awk -F '=' '{printf $2}'`
    NETWORKCARD=""
    MODULESFLAG="1"
    ZKFLAG="1"
    REDISFLAG="1"
    NGINXFLAG="1"
    KAFKAFLAG="1"
    if [ "$MONITORSERVERIP"x == "$NODEIP"x ]; then
        MONITORSERVERFLAG="1"           
    fi
    echo "====================================" >> $LOGFILE
    echo "NODE1IP:$NODE1IP" >> $LOGFILE
    echo "NODE2IP:$NODE2IP" >> $LOGFILE
    echo "VIRTUALIP:$VIRTUALIP" >> $LOGFILE
    echo "DESIP:$DESIP" >> $LOGFILE
    echo "NETWORKCARD:$NETWORKCARD" >> $LOGFILE

    #zk集群配置
    echo "config zookeeper..." >> $LOGFILE
    cd $DEPLOY_PATH/config/zk
    cp zoo-default.cfg zoo.cfg
    sed -i "s/NODE1IP/$NODE1IP/g;s/NODE2IP/$NODE2IP/g" zoo.cfg
    myid='1'
    if [ "$NODEIP"x == "$NODE2IP"x ]; then
        myid='2'
    fi
    cp myid-default myid
    sed -i "s/MYID/$myid/g" myid
    #zk连接字符串
    cp zkConfig-default.properties zkConfig.properties
    ZKADDRESSES="$NODE1IP:27101?backup=$NODE2IP:27101"
    sed -i "s/ZKADDRESSES/$ZKADDRESSES/g" zkConfig.properties

    #设置dubbo.properties
    cd $DEPLOY_PATH/config/module
    cp dubbo-default.properties dubbo.properties
    sed -i "s/DUBBO_REGISTRY_ADDRESS/$ZKADDRESSES/g" dubbo.properties

    #redis配置
    
    #redis连接字符串
    cp redisConfig-default.properties redisConfig.properties
    sed -i "s/REDISIP/$DESIP/g" redisConfig.properties



    #redis配置
    echo "config redis..." >> $LOGFILE
    cd $DEPLOY_PATH/config/redis
    cp redis-default.conf redis.conf
    sed -i "s/NODEIP/$NODEIP/g" redis.conf
    
    REDISMASTER=`cat $DEPLOY_CONFIG | awk "/NODE1IP/" | awk -F '=' '{printf $2}'`
    cp sentinel-default.conf sentinel.conf
    sed -i "s/SENTINELIP/$NODEIP/g;s/MASTERIP/$REDISMASTER/g" sentinel.conf
    if [ "$REDISMASTER"x != "$NODEIP"x ]; then
        echo "slaveof $REDISMASTER 27201" >> redis.conf
    fi
    REDISADDRESS=${REDISMASTER}":27202"
    REDISIP=`cat $DEPLOY_CONFIG | awk "/NODE2IP/" | awk -F '=' '{printf $2}'`
    echo ">>>>>REDISIP:$REDISIP" >> $LOGFILE
    REDISADDRESS=${REDISADDRESS}","${REDISIP}":27202"
    echo ">>>>>REDISFLAG:$REDISFLAG" >> $LOGFILE
    
    #redis连接字符串
    cp redisConfig-default.properties redisConfig.properties
    sed -i "s/REDISIP/$REDISADDRESS/g" redisConfig.properties

    #nginx配置
    echo "config nginx..." >> $LOGFILE
    cd $DEPLOY_PATH/config/nginx
    cp nginx-default.conf nginx.conf
    sed -i "s/NODE1IP/$NODE1IP/g;s/NODE2IP/$NODE2IP/g" nginx.conf

    #keepalived配置
    echo "config keepalived..." >> $LOGFILE
    cd $DEPLOY_PATH/config/keepalived
    cp config-default.conf config.conf
    cp config-default.properties config.properties
    cp keepalived-default.conf keepalived.conf
    STATE='BACKUP'
    NETWORKCARD = $NODE2NETCARD
    if [ "$NODEIP"x == "$NODE1IP"x ]; then
        STATE='MASTER'
        NETWORKCARD=$NODE1NETCARD
    fi
    sed -i "s/NODE1IP/$NODE1IP/g;s/NODE2IP/$NODE2IP/g;s/NODEIP/$NODEIP/g;s/VIRTUALIP/$VIRTUALIP/g;s/DESIP/$DESIP/g;s/STATE/$STATE/g;s/eth0/$NETWORKCARD/g" config.conf
    sed -i "s/NODE1IP/$NODE1IP/g;s/NODE2IP/$NODE2IP/g;s/NODEIP/$NODEIP/g;s/VIRTUALIP/$VIRTUALIP/g;s/DESIP/$DESIP/g;s/STATE/$STATE/g;s/eth0/$NETWORKCARD/g" config.properties
    sed -i "s/NODE1IP/$NODE1IP/g;s/NODE2IP/$NODE2IP/g;s/NODEIP/$NODEIP/g;s/VIRTUALIP/$VIRTUALIP/g;s/DESIP/$DESIP/g;s/STATE/$STATE/g;s/eth0/$NETWORKCARD/g" keepalived.conf

    #kafaka配置
    echo "config kafka..." >> $LOGFILE
    cd $DEPLOY_PATH/config/kafka
    cp kafka.server.default.properties server.properties
    KAFKA_ZK="$NODE1IP:27101,$NODE2IP:27101"
      # 设置broker的id
    KAFKA_UNIQUE_ID=0
    if [ "$NODEIP"x == "$NODE2IP"x ]; then 
        KAFKA_UNIQUE_ID=1
    fi

    sed -i "s#KAFKA_UNIQUE_ID#$KAFKA_UNIQUE_ID#g;s#NODE_IP#$NODEIP#g;s#KAFKA_LOG_DIRS#/usr/local/karaf/kafka_2.11-1.0.0/logs#g;s#KAFKA_ZK#$KAFKA_ZK#g" server.properties
    KAFKA_SERVER_HOST="$NODE1IP:27301,$NODE2IP:27301"
    cp kafkaConfig.default.properties kafkaConfig.properties
    sed -i "s#KAFKA_SERVER_HOST#$KAFKA_SERVER_HOST#g" kafkaConfig.properties
}

readGroupDeployConfig(){
    ZKCOUNT=`cat $DEPLOY_CONFIG | awk '/ZKCOUNT/' | awk -F '=' '{printf $2}'`
    REDISCOUNT=`cat $DEPLOY_CONFIG | awk '/REDISCOUNT/' | awk -F '=' '{printf $2}'`
    MODULESCOUNT=`cat $DEPLOY_CONFIG | awk '/MODULESCOUNT/' | awk -F '=' '{printf $2}'`
    VIRTUALIP=`cat $DEPLOY_CONFIG | awk '/VIRTUALIP/' | awk -F '=' '{printf $2}'`
    NGINXIP1=`cat $DEPLOY_CONFIG | awk '/NGINXIP1/' | awk -F '=' '{printf $2}'`
    NGINXIP2=`cat $DEPLOY_CONFIG | awk '/NGINXIP2/' | awk -F '=' '{printf $2}'`
    MONITORSERVERIP=`cat $DEPLOY_CONFIG | awk '/MONITORSERVERIP/' | awk -F '=' '{printf $2}'`
    NETWORKCARD=`cat $DEPLOY_CONFIG | awk '/NETWORKCARD/' | awk -F '=' '{printf $2}'`
    echo "====================================" >> $LOGFILE
    echo "ZKCOUNT:$ZKCOUNT" >> $LOGFILE
    echo "REDISCOUNT:$REDISCOUNT" >> $LOGFILE
    echo "MODULESCOUNT:$MODULESCOUNT" >> $LOGFILE
    echo "VIRTUALIP:$VIRTUALIP" >> $LOGFILE
    echo "NGINXIP1:$NGINXIP1" >> $LOGFILE
    echo "NGINXIP2:$NGINXIP2" >> $LOGFILE

    for i in  $( seq 1 $MODULESCOUNT )
    do
        MODULEIP=`cat $DEPLOY_CONFIG | awk "/MODULESIP$i/" | awk -F '=' '{printf $2}'`
        if [ "$MODULEIP"x == "$NODEIP"x ]; then
            #标识当前modual组件需要安装
            MODULESFLAG="1"
        fi
    done
    echo ">>>>>MODULESFLAG>>>>>$MODULESFLAG" >> $LOGFILE
    
    #nginx配置
    echo "config nginx..." >> $LOGFILE
    
    if [ "$NGINXIP1"x == "$NODEIP"x ] || [ "$NGINXIP2"x == "$NODEIP"x ]; then
        NGINXFLAG="1"
        
        cd $DEPLOY_PATH/config/nginx
        cp nginx-group-default.conf nginx.conf

        for i in  $( seq 1 $MODULESCOUNT )
        do
            MODULEIP=`cat $DEPLOY_CONFIG | awk "/MODULESIP$i/" | awk -F '=' '{printf $2}'`
            
            echo ">>>>>MODULEIP:$MODULEIP" >> $LOGFILE
            sed -i "/#PORTAL_SERVER_LIST_END/i\server $MODULEIP:28102;" nginx.conf
            sed -i "/#INTERFACE_SERVER_LIST_END/i\server $MODULEIP:28602;" nginx.conf
            sed -i "/#AUTHZ_SERVER_LIST_END/i\server $MODULEIP:28702;" nginx.conf
        done
        sed -i "/#MONITOR_SERVER_LIST_END/i\server $MONITORSERVERIP:29102;" nginx.conf

        #keepalived配置
        echo "config keepalived..." >> $LOGFILE
        cd $DEPLOY_PATH/config/keepalived
        cp config-nginx-default.conf config.conf
        cp config-nginx-default.properties config.properties
        cp keepalived-nginx-default.conf keepalived.conf
        STATE='BACKUP'
        if [ "$NODEIP"x == "$NGINXIP1"x ]; then
            STATE='MASTER'
        fi
        sed -i "s/NODE1IP/$NGINXIP1/g;s/NODE2IP/$NGINXIP2/g;s/NODEIP/$NODEIP/g;s/VIRTUALIP/$VIRTUALIP/g;s/STATE/$STATE/g;s/eth0/$NETWORKCARD/g" config.conf
        sed -i "s/NODE1IP/$NGINXIP1/g;s/NODE2IP/$NGINXIP2/g;s/NODEIP/$NODEIP/g;s/VIRTUALIP/$VIRTUALIP/g;s/STATE/$STATE/g;s/eth0/$NETWORKCARD/g" config.properties
        sed -i "s/NODE1IP/$NGINXIP1/g;s/NODE2IP/$NGINXIP2/g;s/NODEIP/$NODEIP/g;s/VIRTUALIP/$VIRTUALIP/g;s/STATE/$STATE/g;s/eth0/$NETWORKCARD/g" keepalived.conf

    fi
    echo ">>>>>NGINXFLAG>>>>>$NGINXFLAG" >> $LOGFILE

    #zk集群配置
    echo "config zookeeper..." >> $LOGFILE
    cd $DEPLOY_PATH/config/zk
    cp zoo-group-default.cfg zoo.cfg
    cp myid-default myid

    ZKADDRESSES=""
    KAFKA_ZK=""
      # 设置broker的id
    KAFKA_UNIQUE_ID=0
    KAFKA_SERVER_HOST="" #"$NODE1IP:27301,$NODE2IP:27301"
    zkmaster="master"
    for i in $( seq 1 $ZKCOUNT )
    do
        ZKIP=`cat $DEPLOY_CONFIG | awk "/ZKIP$i/" | awk -F '=' '{printf $2}'`
        echo ">>>>>ZKIP:$ZKIP" >> $LOGFILE
        if [ "$ZKIP"x == "$NODEIP"x ]; then
            myid=$i
            KAFKA_UNIQUE_ID=`expr $i - 1`
            sed -i "s/MYID/$myid/g" myid
            ZKFLAG="1"
            KAFKAFLAG="1"
        fi
        echo "server.$i=$ZKIP:27102:27103" >> zoo.cfg
        if [ "$ZKADDRESSES"x != ""x ]; then

            if [ "$zkmaster"x == "slave"x ]; then 
                ZKADDRESSES=${ZKADDRESSES}","${ZKIP}":27101"
            else
                ZKADDRESSES="${ZKADDRESSES}""${ZKIP}"":27101"
            fi
            KAFKA_ZK=$KAFKA_ZK","$ZKIP":27101"
            KAFKA_SERVER_HOST=$KAFKA_SERVER_HOST","$ZKIP":27301"
            zkmaster="slave"
        else
            ZKADDRESSES=${ZKIP}":27101?backup="
            KAFKA_ZK=$ZKIP":27101"
            KAFKA_SERVER_HOST=$ZKIP":27301"
        fi
    done
    echo ">>>>>ZKFLAG>>>>>$ZKFLAG" >> $LOGFILE

    #kafaka配置
    echo "config kafka..." >> $LOGFILE
    cd $DEPLOY_PATH/config/kafka
    cp kafka.server.default.properties server.properties
    sed -i "s#KAFKA_UNIQUE_ID#$KAFKA_UNIQUE_ID#g;s#NODE_IP#$NODEIP#g;s#KAFKA_LOG_DIRS#/usr/local/karaf/kafka_2.11-1.0.0/logs#g;s#KAFKA_ZK#$KAFKA_ZK#g" server.properties
       
 
    cp kafkaConfig.default.properties kafkaConfig.properties
    sed -i "s#KAFKA_SERVER_HOST#$KAFKA_SERVER_HOST#g" kafkaConfig.properties

    #zk连接字符串
    if [ "1"x == "$MODULESFLAG"x ]; then
        cp zkConfig-default.properties zkConfig.properties
        sed -i "s/ZKADDRESSES/$ZKADDRESSES/g" zkConfig.properties
        echo "ZKADDRESSES:$ZKADDRESSES" >> $LOGFILE
    fi


    #设置dubbo.properties 
    if [ "$MONITORSERVERIP"x == "$NODEIP"x ]; then
        MONITORSERVERFLAG="1"
        cd $DEPLOY_PATH/config/module
        cp dubbo-default.properties dubbo.properties
        sed -i "s/DUBBO_REGISTRY_ADDRESS/$ZKADDRESSES/g" dubbo.properties
    fi
    #redis配置
    echo "config redis..." >> $LOGFILE
    cd $DEPLOY_PATH/config/redis
    cp redis-default.conf redis.conf
    sed -i "s/NODEIP/$NODEIP/g" redis.conf
    
    REDISMASTER=`cat $DEPLOY_CONFIG | awk "/REDISIP1/" | awk -F '=' '{printf $2}'`
    cp sentinel-default.conf sentinel.conf
    sed -i "s/SENTINELIP/$NODEIP/g;s/MASTERIP/$REDISMASTER/g" sentinel.conf
    if [ "$REDISMASTER"x != "$NODEIP"x ]; then
        echo "slaveof $REDISMASTER 27201" >> redis.conf
    else
        REDISFLAG="1"
    fi

    REDISADDRESS=${REDISMASTER}":27202"
    for i in $( seq 2 $REDISCOUNT )
    do
        REDISIP=`cat $DEPLOY_CONFIG | awk "/REDISIP$i/" | awk -F '=' '{printf $2}'`
        if [ "$REDISIP"x == "$NODEIP"x ]; then
            REDISFLAG="1"
        fi

        echo ">>>>>REDISIP:$REDISIP" >> $LOGFILE
        REDISADDRESS=${REDISADDRESS}","${REDISIP}":27202"
    done
    echo ">>>>>REDISFLAG:$REDISFLAG" >> $LOGFILE

    
    #redis连接字符串
    if [ "1"x == "$MODULESFLAG"x ]; then
        cp redisConfig-default.properties redisConfig.properties
        sed -i "s/REDISIP/$REDISADDRESS/g" redisConfig.properties
    fi
    echo ">>>>>STSFLAG:$STSFLAG" >> $LOGFILE
}

readConfig(){
        DEPLOY_CONFIG=$DEPLOY_PATH/deploy.cfg
        DBIP=`cat $DEPLOY_CONFIG | awk '/DBIP/' | awk -F '=' '{printf $2}'`
        DBSID=`cat $DEPLOY_CONFIG | awk '/DBSID/' | awk -F '=' '{printf $2}'`
        DBPORT=`cat $DEPLOY_CONFIG | awk '/DBPORT/' | awk -F '=' '{printf $2}'`
        DBADDRESS="$DBIP:$DBPORT/$DBSID"
        NODEIP=`cat $DEPLOY_CONFIG | awk '/NODEIP/' | awk -F '=' '{printf $2}'`
        
        echo "====================================" >> $LOGFILE
        echo "DEPLOY_CONFIG:$DEPLOY_CONFIG" >> $LOGFILE
        echo "DBADDRESS:$DBADDRESS" >> $LOGFILE
        echo "NODEIP:$NODEIP" >> $LOGFILE

        DEPLOYTYPE=`cat $DEPLOY_CONFIG | awk '/DEPLOYTYPE/' | awk -F '=' '{printf $2}'`
    echo "DEPLOYTYPE:$DEPLOYTYPE" >> $LOGFILE
    if [ "$DEPLOYTYPE"x == "Dual"x ]; then
        readDualDeployConfig
    elif [ "$DEPLOYTYPE"x == "Group"x ]; then
        readGroupDeployConfig
    elif [ "$DEPLOYTYPE"x == "Single"x ]; then
        readSingleDeployConfig
    else
        echo "deploy type error:$DEPLOYTYPE,exit;" >> $LOGFILE
        echo "INSTALL ALL END" >> $LOGFILE
        exit 0;
    fi
}

ntpdateFromMODULE1(){
    #集群时从NODEIP1同步时间
    #先启动各服务上ntp。
    service ntp restart
    #sntp -V -P no -r pool.ntp.org
    #sleep 5s
    DEPLOY_CONFIG=$DEPLOY_PATH/deploy.cfg
    DEPLOYTYPE=`cat $DEPLOY_CONFIG | awk '/DEPLOYTYPE/' | awk -F '=' '{printf $2}'`
    NODEIP=`cat $DEPLOY_CONFIG | awk '/NODEIP/' | awk -F '=' '{printf $2}'`
    MODULESIP1=`cat $DEPLOY_CONFIG | awk '/MODULESIP1/' | awk -F '=' '{printf $2}'`
    #所有服务器往默认的第一台主机上同步时间
    echo "ntpdate from $MODULESIP1" >> $LOGFILE
    if [ "$NODEIP"x != "$MODULESIP1"x ]; then
        ntpdate -u $MODULESIP1 >> $LOGFILE
    fi

}

echo "====================================" >> $LOGFILE
echo "`date +%Y-%m-%d' '%H:%M:%S` deploy start..." >> $LOGFILE
echo "====================================" >> $LOGFILE

#解压缩安装包
unzip -oq $DEPLOY_PATH/shell.zip -d $DEPLOY_PATH >> $LOGFILE
unzip -oq $DEPLOY_PATH/soft.zip -d $DEPLOY_PATH/soft >> $LOGFILE
unzip -oq $DEPLOY_PATH/war.zip -d $DEPLOY_PATH/war >> $LOGFILE

#释放内存
#1、先将内存刷出，避免数据丢失
sync
# echo 1 > /proc/sys/vm/drop_caches //释放pagecache
# echo 2 > /proc/sys/vm/drop_caches //释放dentry和inode
# echo 3 > /proc/sys/vm/drop_caches //释放pagecache、dentry和inode
echo 1 > /proc/sys/vm/drop_caches
echo 2 > /proc/sys/vm/drop_caches
echo 3 > /proc/sys/vm/drop_caches

if [ ! -d "$DEPLOY_PATH/soft" ];
then
    echo "cann't find soft ,exit;'" >> $LOGFILE
    echo "INSTALL ALL END" >> $LOGFILE
    exit 0;
fi

if [ ! -d "$DEPLOY_PATH/war" ];
then
    echo "cann't find war ,exit;'" >> $LOGFILE
    echo "INSTALL ALL END" >> $LOGFILE
    exit 0;
fi

if [ ! -d "$DEPLOY_PATH/bin" ];
then
    echo "cann't find bin ,exit;'" >> $LOGFILE
    echo "INSTALL ALL END" >> $LOGFILE
    exit 0;
fi

#配置文件初始化
readConfig
#同步时间
if [ "$DEPLOYTYPE"x == "Group"x ]; then
    ntpdateFromMODULE1
else
     echo "Single does nott need sync date" >> $LOGFILE
fi

echo "====================================" >> $LOGFILE
        
#应用配置文件
    #jdbc连接字符串
    echo "config jdbc..." >> $LOGFILE
    cd $DEPLOY_PATH/config/jdbc
    cp dbConfig-default.properties dbConfig.properties
    sed -i "s#DBADDRESS#$DBADDRESS#g" dbConfig.properties

    #tomcat jvm参数
echo "====================================" >> $LOGFILE

#jdk安装
cd $DEPLOY_PATH/bin
chmod 755 ./*.sh
sh jdkInstall.sh >> $LOGFILE
echo "====================================" >> $LOGFILE


#zk安装
if [ "1"x == "$ZKFLAG"x ]; then
    cd $DEPLOY_PATH/bin/zk
    chmod 755 ./*
    ./zk.sh install >> $LOGFILE
    ./zk.sh start >> $LOGFILE
fi
echo "====================================" >> $LOGFILE

#kafka安装
if [ "1"x == "$KAFKAFLAG"x ]; then
    cd $DEPLOY_PATH/bin/kafka
    chmod 755 ./*
    ./kafka install >> $LOGFILE
    ./kafka start >> $LOGFILE
fi
echo "====================================" >> $LOGFILE

#用户目录设置
#用户目录设置
cd $DEPLOY_PATH/bin
chmod 755 ./*
sh userInit.sh epms epms epms123 >> $LOGFILE
echo "====================================" >> $LOGFILE


#redis安装
if [ "1"x == "$REDISFLAG"x ]; then
    cd $DEPLOY_PATH/bin/redis
    chmod 755 ./*

        ./redis install SENTINELFLG>> $LOGFILE
        ./redis start SENTINELFLG>> $LOGFILE

        #./redis install>> $LOGFILE
        #./redis start>> $LOGFILE

    echo "====================================" >> $LOGFILE
fi
#nginx安装
if [ "1"x == "$NGINXFLAG"x ]; then
    cd $DEPLOY_PATH/bin/nginx
    chmod 755 ./*
    ./nginx.sh install >> $LOGFILE
    ./nginx.sh start >> $LOGFILE
    echo "====================================" >> $LOGFILE

fi

if [ "$DEPLOYTYPE"x != "Single"x ]; then
    #keepalived安装
	cd $DEPLOY_PATH/bin/keepalived
	chmod 755 ./*
	sh install.sh >> $LOGFILE
	echo "====================================" >> $LOGFILE
fi

#随机自启动配置
cd /etc/init.d
AFTER_LOCAL="after.local"
if [ ! -e $AFTER_LOCAL ]; then
    touch  $AFTER_LOCAL
    chmod 755 $AFTER_LOCAL
    echo "cd $DEPLOY_PATH" >> $AFTER_LOCAL
    echo "sleep 300s" >> $AFTER_LOCAL
    echo "sh restart-all.sh restart.log epms" >> $AFTER_LOCAL
fi

#应用安装
#9个模块安装
if [ "1"x == "$MODULESFLAG"x ]; then
    echo "$USER install module ..." >> $LOGFILE
	chown $USER $LOGFILE
	chown $USER $DEPLOY_PATH/war/*
	chown $USER $DEPLOY_PATH/soft/*
	chown $USER $DEPLOY_PATH/bin/module/*
    chown -R $USER $DEPLOY_PATH/config/*
    cd $DEPLOY_PATH/bin/module
    chmod 755 ./*
    ./moduleAll.sh install $USER >> $LOGFILE
fi
#监控告警模块安装
#MONITORSERVER
sleep 10s
MONITORSERVERIP=`cat $DEPLOY_CONFIG | awk '/MONITORSERVERIP/' | awk -F '=' '{printf $2}'`
if [ "1"x == "$MONITORSERVERFLAG"x ]; then 
    echo "MONITORSERVER install..." >> $LOGFILE
    sleep 10s
    cd $DEPLOY_PATH/bin/module
    chmod 755 *
    ./moduleNew.sh install epms monitor  >> $LOGFILE
    # ./moduleNew.sh restart epms monitor >> $LOGFILE &
	
fi
echo "====================================" >> $LOGFILE

#MONITOR CLIENT 安装,MONITORSERVER自带采集功能，所以安装SERVER就不启动CLIENT
#将SERVICE_IP设置为MONITORSERVERIP
cd $DEPLOY_PATH/bin/monitorClient
chmod 755 *
./monitorClient.sh  install $MONITORSERVERIP >> $LOGFILE &
if [ "0"x == "$MONITORSERVERFLAG"x ]; then 
#获取监听服务地址
./monitorClient.sh  restart >> $LOGFILE &
fi
#dubbo监控模块安装

echo "INSTALL ALL END" >> $LOGFILE