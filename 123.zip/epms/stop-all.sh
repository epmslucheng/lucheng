#!/bin/sh
echo "stop all..."
USER="$2"
echo "USER:" $USER
DEPLOY_PATH='/usr/local/deploy'
export DEPLOY_PATH
#指定日志文件
LOGFILE="$DEPLOY_PATH/log/$1"
export LOGFILE


#读取配置文件
 #定义是否启动标识
MODULESFLAG="0"
ZKFLAG="0"
REDISFLAG="0"
NGINXFLAG="0"
MONITORSERVERFLAG="0"
KAFKAFLAG="0"

#单机配置
readSingleDeployConfig(){

        MODULESFLAG="1"
        ZKFLAG="1"
        REDISFLAG="1"
        NGINXFLAG="1"
        MONITORSERVERFLAG="1"
        KAFKAFLAG="1"
}

#双机配置
readDualDeployConfig(){
    MODULESFLAG="1"
    ZKFLAG="1"
    REDISFLAG="1"
    NGINXFLAG="1"
    KAFKAFLAG="1"
    if [ "$MONITORSERVERIP"x == "$NODEIP"x ]; then
        MONITORSERVERFLAG="1"           
    fi



   }

readGroupDeployConfig(){
    ZKCOUNT=`cat $DEPLOY_CONFIG | awk '/ZKCOUNT/' | awk -F '=' '{printf $2}'`
    REDISCOUNT=`cat $DEPLOY_CONFIG | awk '/REDISCOUNT/' | awk -F '=' '{printf $2}'`
    MODULESCOUNT=`cat $DEPLOY_CONFIG | awk '/MODULESCOUNT/' | awk -F '=' '{printf $2}'`
    VIRTUALIP=`cat $DEPLOY_CONFIG | awk '/VIRTUALIP/' | awk -F '=' '{printf $2}'`
    NGINXIP1=`cat $DEPLOY_CONFIG | awk '/NGINXIP1/' | awk -F '=' '{printf $2}'`
    NGINXIP2=`cat $DEPLOY_CONFIG | awk '/NGINXIP2/' | awk -F '=' '{printf $2}'`
    MONITORSERVERIP=`cat $DEPLOY_CONFIG | awk '/MONITORSERVERIP/' | awk -F '=' '{printf $2}'`

    echo "====================================" >> $LOGFILE
    echo "ZKCOUNT:$ZKCOUNT" >> $LOGFILE
    echo "REDISCOUNT:$REDISCOUNT" >> $LOGFILE
    echo "MODULESCOUNT:$MODULESCOUNT" >> $LOGFILE
    echo "VIRTUALIP:$VIRTUALIP" >> $LOGFILE
    echo "NGINXIP1:$NGINXIP1" >> $LOGFILE
    echo "NGINXIP2:$NGINXIP2" >> $LOGFILE

    
    #monitorServer安装标识
    if [ "$MONITORSERVERIP"x == "$NODEIP"x ]; then
        MONITORSERVERFLAG="1"
    fi
    echo ">>>>>MONITORSERVERFLAG>>>>>>${MONITORSERVERFLAG}" >> $LOGFILE

    #获取MODULE安装标识
    for i in  $( seq 1 $MODULESCOUNT )
    do
        MODULEIP=`cat $DEPLOY_CONFIG | awk "/MODULESIP$i/" | awk -F '=' '{printf $2}'`
        if [ "$MODULEIP"x == "$NODEIP"x ]; then
            #标识当前modual组件需要安装
            MODULESFLAG="1"
        fi
    done
    echo ">>>>>MODULESFLAG>>>>>$MODULESFLAG" >> $LOGFILE
    
    #nginx配置
    echo "config nginx..." >> $LOGFILE
    
    if [ "$NGINXIP1"x == "$NODEIP"x ] || [ "$NGINXIP2"x == "$NODEIP"x ]; then
        NGINXFLAG="1"
        #keepalived配置
    fi
    echo ">>>>>NGINXFLAG>>>>>$NGINXFLAG" >> $LOGFILE

    #zk集群配置
    echo "config zookeeper..." >> $LOGFILE

    for i in $( seq 1 $ZKCOUNT )
    do
        ZKIP=`cat $DEPLOY_CONFIG | awk "/ZKIP$i/" | awk -F '=' '{printf $2}'`
        echo ">>>>>ZKIP:$ZKIP" >> $LOGFILE
        if [ "$ZKIP"x == "$NODEIP"x ]; then
            ZKFLAG="1"
            KAFKAFLAG="1"
        fi
    done
    echo ">>>>>ZKFLAG>>>>>$ZKFLAG" >> $LOGFILE

    #redis配置
    echo "config redis..." >> $LOGFILE
    for i in $( seq 1 $REDISCOUNT )
    do
        REDISIP=`cat $DEPLOY_CONFIG | awk "/REDISIP$i/" | awk -F '=' '{printf $2}'`
        if [ "$REDISIP"x == "$NODEIP"x ]; then
            REDISFLAG="1"
        fi
    done
    echo ">>>>>REDISFLAG:$REDISFLAG" >> $LOGFILE       
}

readConfig(){
    DEPLOY_CONFIG=$DEPLOY_PATH/deploy.cfg
    NODEIP=`cat $DEPLOY_CONFIG | awk '/NODEIP/' | awk -F '=' '{printf $2}'`
    
    echo "====================================" >> $LOGFILE
    echo "DEPLOY_CONFIG:$DEPLOY_CONFIG" >> $LOGFILE
    echo "NODEIP:$NODEIP" >> $LOGFILE

    DEPLOYTYPE=`cat $DEPLOY_CONFIG | awk '/DEPLOYTYPE/' | awk -F '=' '{printf $2}'`
    echo "DEPLOYTYPE:$DEPLOYTYPE" >> $LOGFILE
    if [ "$DEPLOYTYPE"x == "Dual"x ]; then
        readDualDeployConfig
    elif [ "$DEPLOYTYPE"x == "Group"x ]; then
        readGroupDeployConfig
    elif [ "$DEPLOYTYPE"x == "Single"x ]; then
        readSingleDeployConfig
    else
        echo "deploy type error:$DEPLOYTYPE,exit;" >> $LOGFILE
        echo "INSTALL ALL END" >> $LOGFILE
        exit 0;
    fi
}


#读取配置文件获得重启服务标识
readConfig
echo "====================================" >> $LOGFILE

#MONITOR CLIENT 卸载
#将SERVICE_IP设置为MONITORSERVERIP
if [ "0"x == "$MONITORSERVERFLAG"x ]; then
cd $DEPLOY_PATH/bin/monitorClient
./monitorClient.sh  stop  >> $LOGFILE
echo "====================================" >> $LOGFILE
fi

echo "stop monitorServer..." >>  $LOGFILE
if [ "1"x == "$MONITORSERVERFLAG"x ]; then
    cd $DEPLOY_PATH/bin/module
    ./moduleNew.sh stop epms monitor  >> $LOGFILE
fi

echo "====================================" >> $LOGFILE

#kafka停止
echo "stop kafka..."
if [ "1"x == "$KAFKAFLAG"x ]; then
    cd $DEPLOY_PATH/bin/kafka
    chmod 755 ./*
    ./kafka stop >> $LOGFILE
fi
echo "====================================" >> $LOGFILE

echo "stop zookeeper..."
if [ "1"x == "$ZKFLAG"x ]; then
    cd ${DEPLOY_PATH}/bin/zk
    sh zk.sh  stop >> $LOGFILE
fi

echo "====================================" >> $LOGFILE
echo "stop redis..."
if [ "1"x == "$REDISFLAG"x ]; then
    cd ${DEPLOY_PATH}/bin/redis
    ./redis stop SENTINELFLG >> $LOGFILE
    #./redis stop >> $LOGFILE
    
fi

echo "====================================" >> $LOGFILE
echo "stop nginx" >> $LOGFILE
if [ "1"x == "$NGINXFLAG"x ]; then
    cd $DEPLOY_PATH/bin/nginx
    sh nginx.sh stop >> $LOGFILE
fi

echo "====================================" >> $LOGFILE
echo "stop module..."
if [ "1"x == "$MODULESFLAG"x ]; then
    chown $USER $LOGFILE

    echo "====================================" >> $LOGFILE
    cd ${DEPLOY_PATH}/bin/module
    echo "====================================" >> $LOGFILE
    ./moduleAll.sh stop $USER >> $LOGFILE
fi

echo "STOP ALL END" >> $LOGFILE
echo "OPERATION TAIL END" >> $LOGFILE
